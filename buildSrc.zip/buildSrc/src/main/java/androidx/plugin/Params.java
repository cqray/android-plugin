package androidx.plugin;

public class Params {

    public int bb;

    public int getBb() {
        return bb;
    }

    public void setBb(int bb) {
        this.bb = bb;
    }
}
