package androidx.plugin;

import org.gradle.api.Action;
import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.jetbrains.annotations.NotNull;

/**
 * Sdk依赖集合
 * @author LeiJue
 */
public class Sdks implements Plugin<Project> {

    public static final String starter = "com.github.cqray:android-starter:0.5.6";
    public static final String gson = "com.google.code.gson:gson:2.8.8";

    @Override
    public void apply(@NotNull Project project) {

        //"user"使用插件时相应的配置对象
        project.getExtensions().create("user", Params.class);

        project.afterEvaluate(new Action<Project>() {
            @Override
            public void execute(Project project) {
                //获取使用过程中的相应配置参数
                Params user = (Params) project.getExtensions().findByName("user");

                if (user != null && user.bb > 10) {

                    project.getDependencies().add("api", "com.google.code.gson:gson:2.8.8");
                }
            }
        });
    }
}
